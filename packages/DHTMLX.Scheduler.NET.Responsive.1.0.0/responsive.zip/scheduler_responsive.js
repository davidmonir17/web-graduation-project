function initResponsive() {
    if (scheduler.skin === "glossy" || scheduler.skin === "classic") {
        setlink("../Scripts/dhtmlxScheduler/scheduler-adaptive-classic.css");
    }

    if (/Android|webOS|iPhone|iPad|iPod|IEMobile/i.test(navigator.userAgent)) {
        loadScript("../Scripts/dhtmlxScheduler/ext/dhtmlxscheduler_quick_info.js", function () {
            scheduler.config.touch = "force";
            scheduler.xy.menu_width = 0;
        });
    }
    
    function setHavH() {
        try {
            if (typeof scheduler !== "undefined") {
                /*change height of nav bar*/
                if (window.innerWidth >= 768) {
                    scheduler.xy.nav_height = 59;
                    if (scheduler.skin === "glossy" || scheduler.skin === "classic") {
                        scheduler.xy.nav_height = 23;
                    }

                    scheduler.templates.week_scale_date = function (date) {
                        return scheduler.date.date_to_str("%F, %D %d")(date);
                    };
                }
                else {
                    //load script
                    if (scheduler.skin === "glossy" || scheduler.skin === "classic") {
                        scheduler.xy.nav_height = 140;

                    } else {
                        scheduler.xy.nav_height = 130;
                    }
                    scheduler.templates.week_scale_date = function (date) {
                        return scheduler.date.date_to_str("%D %d")(date);
                    };
                }
            }
        } catch (err) {
            console.log(err.message);
            return true;
        }
        return true;
    };

    scheduler.attachEvent("onSchedulerResize",
        function () { scheduler.setCurrentView(); });
    scheduler.attachEvent("onBeforeViewChange", setHavH);
}

function setlink(source) {
    var cssFileTag = document.createElement("link");
    cssFileTag.setAttribute("rel", "stylesheet");
    cssFileTag.setAttribute("type", "text/css");
    cssFileTag.setAttribute("href", source);

    document.getElementsByTagName("head")[0].appendChild(cssFileTag);
}

function loadScript(url, callback) {
    var head = document.getElementsByTagName('head')[0];
    var script = document.createElement('script');
    script.type = 'text/javascript';
    script.src = url;

    script.onreadystatechange = callback;
    script.onload = callback;

    head.appendChild(script);
}